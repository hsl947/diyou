=================

angularjs封装的select2（支持任意版本的select2）

* 支持动态ng-model
* 支持select标签
* 支持自定义配置及多选（与select2原生的配置方式一致）
* 支持ajax
* 支持自定义内置配置

具体使用请下载源码，打开index.html查看。
![demo页面](http://think2011.qiniudn.com/angularjs-select2.png)

---
> ##### 技术： angularjs + jquery + select2
> ##### 时间： 2014年5月
> ##### 博客： [think2011](http://think2011.github.io)
> ##### 源码： [select2](http://ivaynberg.github.io/select2/)
> ##### 源码： [angularjs-select2（当前页面就是）](https://github.com/think2011/angularjs-select2.git)
